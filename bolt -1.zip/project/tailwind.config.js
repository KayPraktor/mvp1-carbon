/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        'chart-green': '#10B981',
        'chart-blue': '#3B82F6',
        'chart-indigo': '#6366F1',
        'chart-purple': '#8B5CF6',
      },
      boxShadow: {
        'glow': '0 0 15px rgba(16, 185, 129, 0.1)',
      }
    },
  },
  plugins: [],
};