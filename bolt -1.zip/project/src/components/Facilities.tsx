import React, { useState } from 'react';
import { Building2, MapPin, Users, Zap, ArrowUpRight, Plus, Filter, Download, Search } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Facilities = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  const facilities = [
    {
      name: 'Main Factory - London',
      type: 'Manufacturing',
      address: '123 Industrial Park, London',
      employees: 450,
      emissions: 523,
      energyUsage: 1250,
      trend: -8.2,
      status: 'operational'
    },
    {
      name: 'Distribution Center - Manchester',
      type: 'Distribution',
      address: '456 Logistics Way, Manchester',
      employees: 180,
      emissions: 245,
      energyUsage: 680,
      trend: 5.7,
      status: 'operational'
    },
    {
      name: 'Office Building - Birmingham',
      type: 'Office',
      address: '789 Business Square, Birmingham',
      employees: 320,
      emissions: 156,
      energyUsage: 420,
      trend: -12.3,
      status: 'operational'
    },
    {
      name: 'Warehouse - Leeds',
      type: 'Storage',
      address: '321 Storage Road, Leeds',
      employees: 85,
      emissions: 310,
      energyUsage: 890,
      trend: 3.4,
      status: 'maintenance'
    }
  ];

  const monthlyData = facilities.map(facility => ({
    name: facility.name.split(' - ')[0],
    emissions: facility.emissions,
    energy: facility.energyUsage
  }));

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value} {entry.name === 'emissions' ? 'tCO2e' : 'MWh'}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Facilities</h1>
          <p className="text-gray-500">Manage and monitor your facilities</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-4 w-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Plus className="h-4 w-4" />
            Add Facility
          </button>
        </div>
      </div>

      <div className="mb-8">
        <div className="relative">
          <input
            type="text"
            placeholder="Search facilities..."
            className="w-full px-4 py-2 pl-10 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Emissions by Facility</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="emissions" fill="#10B981" name="Emissions" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Energy Usage by Facility</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="energy" fill="#3B82F6" name="Energy" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Facility List</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {facilities.map((facility, index) => (
            <div key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <Building2 className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">{facility.name}</h4>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {facility.address}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {facility.employees} employees
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div>
                    <p className="text-sm text-gray-500">Emissions</p>
                    <p className="text-lg font-medium text-gray-900">{facility.emissions} tCO2e</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Energy Usage</p>
                    <p className="text-lg font-medium text-gray-900">{facility.energyUsage} MWh</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Trend</p>
                    <div className="flex items-center gap-1">
                      <ArrowUpRight className={`h-4 w-4 ${facility.trend < 0 ? 'text-green-500 rotate-180' : 'text-red-500'}`} />
                      <span className={`font-medium ${facility.trend < 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {Math.abs(facility.trend)}%
                      </span>
                    </div>
                  </div>
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                    facility.status === 'operational' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {facility.status.charAt(0).toUpperCase() + facility.status.slice(1)}
                  </span>
                  <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-50 rounded-lg hover:bg-gray-100">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Facilities;