import React, { useState } from 'react';
import { Factory, Truck, Building2, Zap, Wind, Trash2, Filter, Download, ArrowUpRight, Plus } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const EmissionSources = () => {
  const [timeRange, setTimeRange] = useState('year');
  const [sourceFilter, setSourceFilter] = useState('all');

  const emissionData = [
    { source: 'Electricity', icon: Zap, value: 450, percentage: 36.5, trend: -8.2, intensity: 0.42 },
    { source: 'Manufacturing', icon: Factory, value: 380, percentage: 30.8, trend: -15.3, intensity: 0.38 },
    { source: 'Transportation', icon: Truck, value: 284, percentage: 23.0, trend: 5.7, intensity: 0.56 },
    { source: 'Facilities', icon: Building2, value: 120, percentage: 9.7, trend: -2.1, intensity: 0.31 }
  ];

  const monthlyData = [
    { name: 'Jan', electricity: 42, manufacturing: 35, transport: 25, facilities: 12 },
    { name: 'Feb', electricity: 38, manufacturing: 32, transport: 28, facilities: 10 },
    { name: 'Mar', electricity: 45, manufacturing: 37, transport: 24, facilities: 11 },
    { name: 'Apr', electricity: 40, manufacturing: 34, transport: 26, facilities: 13 },
    { name: 'May', electricity: 35, manufacturing: 30, transport: 22, facilities: 9 },
    { name: 'Jun', electricity: 48, manufacturing: 38, transport: 30, facilities: 14 }
  ];

  const COLORS = ['#10B981', '#3B82F6', '#6366F1', '#8B5CF6'];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value} tCO2e
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Emission Sources</h1>
          <p className="text-gray-500">Track and manage your emission sources</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-4 w-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Plus className="h-4 w-4" />
            Add Source
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Emissions Distribution</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={emissionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {emissionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Monthly Trends</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="electricity" stackId="a" fill={COLORS[0]} name="Electricity" />
                <Bar dataKey="manufacturing" stackId="a" fill={COLORS[1]} name="Manufacturing" />
                <Bar dataKey="transport" stackId="a" fill={COLORS[2]} name="Transport" />
                <Bar dataKey="facilities" stackId="a" fill={COLORS[3]} name="Facilities" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm mb-8">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Source Details</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {emissionData.map((source, index) => (
            <div key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <source.icon className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">{source.source}</h4>
                    <p className="text-sm text-gray-500">{source.value} tCO2e ({source.percentage}% of total)</p>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div>
                    <p className="text-sm text-gray-500">Carbon Intensity</p>
                    <p className="text-lg font-medium text-gray-900">{source.intensity} kgCO2e/unit</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Trend</p>
                    <div className="flex items-center gap-1">
                      <ArrowUpRight className={`h-4 w-4 ${source.trend < 0 ? 'text-green-500 rotate-180' : 'text-red-500'}`} />
                      <span className={`font-medium ${source.trend < 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {Math.abs(source.trend)}%
                      </span>
                    </div>
                  </div>
                  <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-50 rounded-lg hover:bg-gray-100">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmissionSources;