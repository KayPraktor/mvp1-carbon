import React, { useState } from 'react';
import { Calendar, Filter, Download, ArrowDown, ArrowUp, Info, FileText } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

const Analytics = () => {
  const [timeRange, setTimeRange] = useState('30');
  const [comparisonType, setComparisonType] = useState('previous');
  const [exportLoading, setExportLoading] = useState(false);
  const [pdfLoading, setPdfLoading] = useState(false);

  const metrics = [
    {
      title: 'Total Carbon Footprint',
      value: '2,345',
      unit: 'tCO2e',
      change: -8.2,
      trend: 'decreasing',
      details: 'Compared to previous period'
    },
    {
      title: 'Carbon Intensity',
      value: '0.38',
      unit: 'kgCO2e/unit',
      change: -12.5,
      trend: 'decreasing',
      details: 'Per production unit'
    },
    {
      title: 'Energy Consumption',
      value: '1.2M',
      unit: 'kWh',
      change: 5.3,
      trend: 'increasing',
      details: 'Total energy used'
    },
    {
      title: 'Renewable Energy',
      value: '45',
      unit: '%',
      change: 15.8,
      trend: 'increasing',
      details: 'Of total energy mix'
    }
  ];

  const emissionsData = [
    { month: 'Jan', emissions: 320, target: 350 },
    { month: 'Feb', emissions: 300, target: 345 },
    { month: 'Mar', emissions: 340, target: 340 },
    { month: 'Apr', emissions: 280, target: 335 },
    { month: 'May', emissions: 290, target: 330 },
    { month: 'Jun', emissions: 270, target: 325 },
    { month: 'Jul', emissions: 260, target: 320 },
    { month: 'Aug', emissions: 250, target: 315 },
    { month: 'Sep', emissions: 240, target: 310 },
    { month: 'Oct', emissions: 230, target: 305 },
    { month: 'Nov', emissions: 220, target: 300 },
    { month: 'Dec', emissions: 210, target: 295 }
  ];

  const categoryData = [
    { name: 'Electricity', value: 450, color: '#10B981' },
    { name: 'Manufacturing', value: 380, color: '#3B82F6' },
    { name: 'Transportation', value: 284, color: '#6366F1' },
    { name: 'Facilities', value: 120, color: '#8B5CF6' }
  ];

  const insights = [
    {
      title: 'Peak Emissions Period',
      description: 'Highest emissions recorded during manufacturing hours (10 AM - 4 PM)',
      impact: 'high',
      recommendation: 'Consider load balancing production schedules'
    },
    {
      title: 'Facility Efficiency',
      description: 'Manchester facility showing 15% higher emissions per unit',
      impact: 'medium',
      recommendation: 'Audit equipment efficiency and maintenance schedules'
    },
    {
      title: 'Transport Optimization',
      description: 'Route optimization reduced fleet emissions by 12%',
      impact: 'positive',
      recommendation: 'Expand program to all regional routes'
    }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value} {entry.name === 'emissions' ? 'tCO2e' : ''}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Function to handle data export
  const handleExportData = () => {
    setExportLoading(true);
    
    try {
      // Prepare the data for export
      const exportData = {
        metrics,
        emissionsData,
        categoryData,
        insights,
        exportDate: new Date().toISOString(),
        timeRange,
        comparisonType
      };
      
      // Convert to JSON string
      const jsonString = JSON.stringify(exportData, null, 2);
      
      // Create a blob and download link
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Create a temporary link element and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `analytics-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      // Show success message or notification here if needed
      console.log('Export completed successfully');
    } catch (error) {
      console.error('Export failed:', error);
      // Handle error - could show an error notification here
    } finally {
      setExportLoading(false);
    }
  };

  // Function to export as CSV (alternative format)
  const exportAsCSV = () => {
    setExportLoading(true);
    
    try {
      // Create CSV header
      let csvContent = "Month,Emissions,Target\n";
      
      // Add data rows
      emissionsData.forEach(row => {
        csvContent += `${row.month},${row.emissions},${row.target}\n`;
      });
      
      // Create blob and trigger download
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `emissions-data-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('CSV export failed:', error);
    } finally {
      setExportLoading(false);
    }
  };

  // Function to generate and download PDF report
  const generatePDF = () => {
    setPdfLoading(true);
    
    try {
      // Create new PDF document (A4 format)
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      // Add metadata
      doc.setProperties({
        title: 'Carbon Emissions Analytics Report',
        subject: 'Environmental Data Analysis',
        author: 'Baryonic Carbon Intelligence',
        keywords: 'carbon, emissions, analytics, sustainability',
        creator: 'Baryonic Dashboard'
      });
      
      // Set initial position
      let yPos = 20;
      const pageWidth = doc.internal.pageSize.getWidth();
      
      // Add header with logo placeholder
      doc.setFontSize(20);
      doc.setTextColor(0, 128, 0);
      doc.text('Baryonic Carbon Intelligence', pageWidth / 2, yPos, { align: 'center' });
      
      // Add report title
      yPos += 10;
      doc.setFontSize(16);
      doc.setTextColor(0, 0, 0);
      doc.text('Carbon Emissions Analytics Report', pageWidth / 2, yPos, { align: 'center' });
      
      // Add date
      yPos += 8;
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      const today = new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
      doc.text(`Generated on: ${today}`, pageWidth / 2, yPos, { align: 'center' });
      
      // Add time period
      yPos += 5;
      const timePeriod = timeRange === '7' ? 'Last 7 days' : 
                         timeRange === '30' ? 'Last 30 days' : 
                         timeRange === '90' ? 'Last 90 days' : 'Last 12 months';
      doc.text(`Time Period: ${timePeriod}`, pageWidth / 2, yPos, { align: 'center' });
      
      // Add section divider
      yPos += 10;
      doc.setDrawColor(200, 200, 200);
      doc.line(20, yPos, pageWidth - 20, yPos);
      
      // Key Metrics Section
      yPos += 10;
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text('Key Metrics', 20, yPos);
      
      // Add metrics table
      yPos += 5;
      const metricsTableData = metrics.map(metric => [
        metric.title,
        `${metric.value} ${metric.unit}`,
        `${metric.change > 0 ? '+' : ''}${metric.change}%`,
        metric.details
      ]);
      
      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: yPos,
        head: [['Metric', 'Value', 'Change', 'Details']],
        body: metricsTableData,
        theme: 'grid',
        headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255] },
        margin: { left: 20, right: 20 },
        styles: { fontSize: 10 }
      });
      
      // Get the final Y position after the table
      // @ts-ignore - jspdf-autotable types
      yPos = doc.lastAutoTable.finalY + 10;
      
      // Emissions Data Section
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text('Monthly Emissions Data', 20, yPos);
      
      // Add emissions data table
      yPos += 5;
      const emissionsTableData = emissionsData.map(data => [
        data.month,
        `${data.emissions} tCO2e`,
        `${data.target} tCO2e`,
        data.emissions < data.target ? 'Below Target ✓' : 'Above Target ⚠'
      ]);
      
      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: yPos,
        head: [['Month', 'Actual Emissions', 'Target Emissions', 'Status']],
        body: emissionsTableData,
        theme: 'grid',
        headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255] },
        margin: { left: 20, right: 20 },
        styles: { fontSize: 10 }
      });
      
      // Get the final Y position after the table
      // @ts-ignore - jspdf-autotable types
      yPos = doc.lastAutoTable.finalY + 10;
      
      // Check if we need a new page for the next section
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      
      // Emissions by Category Section
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text('Emissions by Category', 20, yPos);
      
      // Add category data table
      yPos += 5;
      const categoryTableData = categoryData.map(data => [
        data.name,
        `${data.value} tCO2e`,
        `${((data.value / categoryData.reduce((sum, item) => sum + item.value, 0)) * 100).toFixed(1)}%`
      ]);
      
      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: yPos,
        head: [['Category', 'Emissions', 'Percentage']],
        body: categoryTableData,
        theme: 'grid',
        headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255] },
        margin: { left: 20, right: 20 },
        styles: { fontSize: 10 }
      });
      
      // Get the final Y position after the table
      // @ts-ignore - jspdf-autotable types
      yPos = doc.lastAutoTable.finalY + 10;
      
      // Key Insights Section
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);
      doc.text('Key Insights & Recommendations', 20, yPos);
      
      // Add insights table
      yPos += 5;
      const insightsTableData = insights.map(insight => [
        insight.title,
        insight.description,
        insight.impact.charAt(0).toUpperCase() + insight.impact.slice(1),
        insight.recommendation
      ]);
      
      // @ts-ignore - jspdf-autotable types
      doc.autoTable({
        startY: yPos,
        head: [['Finding', 'Description', 'Impact', 'Recommendation']],
        body: insightsTableData,
        theme: 'grid',
        headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255] },
        margin: { left: 20, right: 20 },
        styles: { fontSize: 10 }
      });
      
      // Add footer with page numbers
      const totalPages = doc.internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        doc.setTextColor(100, 100, 100);
        doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, 285, { align: 'center' });
        doc.text('Baryonic Carbon Intelligence - Confidential', pageWidth / 2, 290, { align: 'center' });
      }
      
      // Save the PDF
      doc.save(`carbon-emissions-report-${new Date().toISOString().split('T')[0]}.pdf`);
      
    } catch (error) {
      console.error('PDF generation failed:', error);
      // Handle error - could show an error notification here
    } finally {
      setPdfLoading(false);
    }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-500">Detailed analysis of your carbon emissions and energy usage</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200 px-4 py-2">
            <Calendar className="h-5 w-5 text-gray-400" />
            <select 
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="text-sm text-gray-600 bg-transparent border-none focus:ring-0"
            >
              <option value="7">Last 7 days</option>
              <option value="30">Last 30 days</option>
              <option value="90">Last 90 days</option>
              <option value="365">Last 12 months</option>
            </select>
          </div>
          <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200 px-4 py-2">
            <Filter className="h-5 w-5 text-gray-400" />
            <select 
              value={comparisonType}
              onChange={(e) => setComparisonType(e.target.value)}
              className="text-sm text-gray-600 bg-transparent border-none focus:ring-0"
            >
              <option value="previous">vs Previous Period</option>
              <option value="target">vs Target</option>
              <option value="baseline">vs Baseline</option>
            </select>
          </div>
          <div className="relative group">
            <button 
              onClick={handleExportData}
              disabled={exportLoading}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 relative"
            >
              <Download className="h-5 w-5" />
              {exportLoading ? 'Exporting...' : 'Export Data'}
            </button>
            <div className="absolute right-0 mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-10 hidden group-hover:block">
              <button 
                onClick={handleExportData}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                Export as JSON
              </button>
              <button 
                onClick={exportAsCSV}
                className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                Export as CSV
              </button>
            </div>
          </div>
          <button 
            onClick={generatePDF}
            disabled={pdfLoading}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm hover:bg-green-700"
          >
            <FileText className="h-5 w-5" />
            {pdfLoading ? 'Generating PDF...' : 'Generate PDF Report'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm text-gray-500">{metric.title}</p>
                <div className="flex items-baseline mt-1">
                  <h3 className="text-2xl font-bold text-gray-900">{metric.value}</h3>
                  <span className="ml-1 text-sm text-gray-500">{metric.unit}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {metric.trend === 'decreasing' ? (
                  <ArrowDown className={`h-4 w-4 ${metric.change < 0 ? 'text-green-500' : 'text-red-500'}`} />
                ) : (
                  <ArrowUp className={`h-4 w-4 ${metric.change > 0 ? 'text-green-500' : 'text-red-500'}`} />
                )}
                <span className={`text-sm font-medium ${Math.abs(metric.change) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {Math.abs(metric.change)}%
                </span>
              </div>
            </div>
            <p className="text-sm text-gray-500 flex items-center gap-1">
              <Info className="h-4 w-4" />
              {metric.details}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Emissions Over Time</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={emissionsData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="emissionsGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="month" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="emissions" 
                  stroke="#10B981" 
                  fillOpacity={1} 
                  fill="url(#emissionsGradient)" 
                  name="Emissions"
                />
                <Area 
                  type="monotone" 
                  dataKey="target" 
                  stroke="#6B7280" 
                  strokeDasharray="5 5" 
                  fill="none" 
                  name="Target"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Emissions by Category</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend 
                  verticalAlign="middle" 
                  align="right"
                  layout="vertical"
                  formatter={(value, entry) => (
                    <span className="text-sm text-gray-600">{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {insights.map((insight, index) => (
            <div key={index} className="p-4 rounded-lg bg-gray-50">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium text-gray-900">{insight.title}</h4>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  insight.impact === 'high' ? 'bg-red-100 text-red-700' :
                  insight.impact === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-green-100 text-green-700'
                }`}>
                  {insight.impact}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-3">{insight.description}</p>
              <div className="flex items-start gap-2">
                <Info className="h-4 w-4 text-gray-400 mt-1" />
                <p className="text-sm text-gray-600">{insight.recommendation}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Analytics;