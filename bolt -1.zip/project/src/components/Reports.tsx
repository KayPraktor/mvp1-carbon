import React, { useState } from 'react';
import { FileText, Download, Filter, Calendar, Clock, BarChart3, Mail, Sliders, Plus, RefreshCw, CheckCircle2 } from 'lucide-react';

const Reports = ({ darkMode }) => {
  const [activeTab, setActiveTab] = useState('templates');
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const reportTemplates = [
    {
      id: 'emissions-summary',
      name: 'Emissions Summary',
      description: 'Comprehensive overview of emissions across all facilities',
      type: 'Standard',
      lastGenerated: '2024-03-15',
      format: 'PDF, Excel',
      schedule: 'Monthly'
    },
    {
      id: 'compliance-report',
      name: 'Compliance Report',
      description: 'Regulatory compliance status and documentation',
      type: 'Compliance',
      lastGenerated: '2024-03-10',
      format: 'PDF',
      schedule: 'Quarterly'
    },
    {
      id: 'facility-performance',
      name: 'Facility Performance',
      description: 'Detailed analysis of facility-level emissions and efficiency',
      type: 'Analytics',
      lastGenerated: '2024-03-01',
      format: 'PDF, Excel, PowerPoint',
      schedule: 'Weekly'
    },
    {
      id: 'target-progress',
      name: 'Target Progress',
      description: 'Progress tracking for emission reduction targets',
      type: 'KPI',
      lastGenerated: '2024-03-14',
      format: 'PDF, Dashboard',
      schedule: 'Monthly'
    }
  ];

  const scheduledReports = [
    {
      name: 'Weekly Emissions Summary',
      template: 'Emissions Summary',
      frequency: 'Weekly',
      nextRun: '2024-03-22',
      recipients: ['operations@example.com', 'management@example.com'],
      format: 'PDF'
    },
    {
      name: 'Monthly Compliance Report',
      template: 'Compliance Report',
      frequency: 'Monthly',
      nextRun: '2024-04-01',
      recipients: ['compliance@example.com'],
      format: 'PDF'
    }
  ];

  const recentReports = [
    {
      name: 'March Emissions Summary',
      generated: '2024-03-15 09:30',
      status: 'Completed',
      size: '2.4 MB',
      format: 'PDF'
    },
    {
      name: 'Q1 Compliance Report',
      generated: '2024-03-10 14:15',
      status: 'Completed',
      size: '5.1 MB',
      format: 'PDF'
    },
    {
      name: 'Facility Performance - Week 11',
      generated: '2024-03-17 08:00',
      status: 'Processing',
      size: '-',
      format: 'Excel'
    }
  ];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Reports</h1>
          <p className="text-gray-500 dark:text-gray-400">Generate and manage reports</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <Filter className="h-4 w-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Plus className="h-4 w-4" />
            New Report
          </button>
        </div>
      </div>

      <div className="mb-6">
        <nav className="flex gap-4">
          {['templates', 'scheduled', 'recent'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium rounded-lg ${
                activeTab === tab
                  ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reportTemplates.map((template) => (
            <div
              key={template.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <FileText className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <span className="px-3 py-1 text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-full">
                  {template.type}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{template.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{template.description}</p>
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm">
                  <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-gray-600 dark:text-gray-300">Last generated: {template.lastGenerated}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Download className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-gray-600 dark:text-gray-300">Available formats: {template.format}</span>
                </div>
                <div className="flex items-center text-sm">
                  <RefreshCw className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-gray-600 dark:text-gray-300">Default schedule: {template.schedule}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 px-4 py-2 text-sm font-medium text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-900/20 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30">
                  Generate Now
                </button>
                <button className="flex-1 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600">
                  Schedule
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'scheduled' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Scheduled Reports</h3>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {scheduledReports.map((report, index) => (
              <div key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-lg font-medium text-gray-900 dark:text-white">{report.name}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Template: {report.template}</p>
                  </div>
                  <div className="flex items-center gap-8">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Next Run</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{report.nextRun}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Frequency</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{report.frequency}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Format</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{report.format}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600">
                        Edit
                      </button>
                      <button className="px-4 py-2 text-sm font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30">
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'recent' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Reports</h3>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {recentReports.map((report, index) => (
              <div key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <FileText className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">{report.name}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Generated: {report.generated}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-8">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Status</p>
                      <div className="flex items-center gap-1">
                        {report.status === 'Completed' ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : (
                          <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />
                        )}
                        <span className={`text-sm font-medium ${
                          report.status === 'Completed' ? 'text-green-500' : 'text-blue-500'
                        }`}>
                          {report.status}
                        </span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Size</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{report.size}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Format</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{report.format}</p>
                    </div>
                    <button className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600">
                      Download
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;