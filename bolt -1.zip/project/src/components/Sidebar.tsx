import React from 'react';
import { BarChart3, Building2, Factory, Atom, LineChart, Settings, Users, FileText, Target, AlertCircle, PieChart, Hexagon } from 'lucide-react';

const Sidebar = ({ currentPage, onPageChange, darkMode }) => {
  const menuItems = [
    { id: 'dashboard', icon: BarChart3, label: 'Dashboard' },
    { id: 'visualization', icon: PieChart, label: 'Emissions Data' },
    { id: 'analytics', icon: LineChart, label: 'Analytics' },
    { id: 'emissions', icon: Factory, label: 'Emissions Sources' },
    { id: 'facilities', icon: Building2, label: 'Facilities' },
    { id: 'targets', icon: Target, label: 'Targets' },
    { id: 'reports', icon: FileText, label: 'Reports' },
    { id: 'alerts', icon: AlertCircle, label: 'Alerts' },
    { id: 'team', icon: Users, label: 'Team' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className={`w-64 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-r px-4 py-6 transition-colors duration-200`}>
      <div className="flex items-center gap-2 mb-8 px-2">
        <div className="relative">
          <Hexagon className={`h-9 w-9 ${darkMode ? 'text-green-400' : 'text-green-600'}`} />
          <Atom className="h-5 w-5 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white" />
        </div>
        <div className="flex flex-col">
          <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>Baryonic</span>
          <span className={`text-xs ${darkMode ? 'text-green-400' : 'text-green-600'}`}>Carbon Intelligence</span>
        </div>
      </div>
      <nav className="space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onPageChange(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
              currentPage === item.id
                ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400' 
                : `${darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'}`
            }`}
          >
            <item.icon className={`h-5 w-5 ${
              currentPage === item.id 
                ? 'text-green-600 dark:text-green-400' 
                : 'text-gray-400 dark:text-gray-500'
            }`} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="mt-auto pt-8 px-2">
        <div className={`${darkMode ? 'bg-green-900/20' : 'bg-green-50'} p-4 rounded-lg transition-colors`}>
          <h4 className={`text-sm font-medium ${darkMode ? 'text-green-400' : 'text-green-800'} mb-2`}>Carbon Reduction Target</h4>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-xs ${darkMode ? 'text-green-400' : 'text-green-600'}`}>Progress</span>
            <span className={`text-xs font-medium ${darkMode ? 'text-green-400' : 'text-green-800'}`}>68%</span>
          </div>
          <div className="w-full bg-green-200 dark:bg-green-900 rounded-full h-2">
            <div className="bg-green-600 dark:bg-green-400 h-2 rounded-full" style={{ width: '68%' }} />
          </div>
          <p className={`text-xs ${darkMode ? 'text-green-400' : 'text-green-600'} mt-2`}>32% to reach 2025 goal</p>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;