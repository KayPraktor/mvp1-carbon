import React from 'react';
import { BarChart3, TrendingDown, TrendingUp, AlertCircle, Building2, Factory, Truck, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ComposableMap, Geographies, Geography, ZoomableGroup } from 'react-simple-maps';
import { scaleLinear } from 'd3-scale';

const Dashboard = () => {
  const stats = [
    {
      title: 'Total Emissions',
      value: '1,234',
      unit: 'tCO2e',
      change: -12.5,
      period: 'vs last month'
    },
    {
      title: 'Energy Usage',
      value: '45,678',
      unit: 'kWh',
      change: 8.2,
      period: 'vs last month'
    },
    {
      title: 'Carbon Intensity',
      value: '0.42',
      unit: 'kgCO2e/kWh',
      change: -5.3,
      period: 'vs last month'
    }
  ];

  const emissionSources = [
    { name: 'Electricity', icon: Zap, value: 450, percentage: 36.5, change: -8.2 },
    { name: 'Manufacturing', icon: Factory, value: 380, percentage: 30.8, change: -15.3 },
    { name: 'Transportation', icon: Truck, value: 284, percentage: 23.0, change: 5.7 },
    { name: 'Facilities', icon: Building2, value: 120, percentage: 9.7, change: -2.1 }
  ];

  const facilities = [
    { name: 'Main Factory - London', emissions: 523, status: 'On Track', alert: false },
    { name: 'Distribution Center - Manchester', emissions: 245, status: 'Warning', alert: true },
    { name: 'Office Building - Birmingham', emissions: 156, status: 'On Track', alert: false },
    { name: 'Warehouse - Leeds', emissions: 310, status: 'Critical', alert: true }
  ];

  const emissionTrends = [
    { month: 'Jan', emissions: 1500 },
    { month: 'Feb', emissions: 1450 },
    { month: 'Mar', emissions: 1400 },
    { month: 'Apr', emissions: 1320 },
    { month: 'May', emissions: 1280 },
    { month: 'Jun', emissions: 1234 }
  ];

  // Carbon intensity data for the map
  const carbonIntensityData = {
    type: "FeatureCollection",
    features: [
      { id: "CHN", intensity: 443, name: "China" },
      { id: "USA", intensity: 223, name: "United States" },
      { id: "IND", intensity: 412, name: "India" },
      { id: "RUS", intensity: 496, name: "Russia" },
      { id: "JPN", intensity: 185, name: "Japan" },
      { id: "DEU", intensity: 156, name: "Germany" },
      { id: "GBR", intensity: 142, name: "United Kingdom" },
      { id: "FRA", intensity: 105, name: "France" }
    ]
  };

  const colorScale = scaleLinear()
    .domain([0, 200, 400, 600])
    .range(["#10B981", "#FCD34D", "#F59E0B", "#EF4444"]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm text-gray-600">
              {entry.name}: {entry.value} tCO2e
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">Track and manage your carbon emissions</p>
        </div>
        <div className="flex gap-4">
          <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            Export Report
          </button>
          <button className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            Add New Data
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm text-gray-500">{stat.title}</p>
                <div className="flex items-baseline">
                  <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                  <span className="ml-1 text-sm text-gray-500">{stat.unit}</span>
                </div>
              </div>
              <BarChart3 className="h-6 w-6 text-gray-400" />
            </div>
            <div className="flex items-center">
              {stat.change > 0 ? (
                <TrendingUp className="h-4 w-4 text-red-500 mr-1" />
              ) : (
                <TrendingDown className="h-4 w-4 text-green-500 mr-1" />
              )}
              <span className={`text-sm ${stat.change > 0 ? 'text-red-500' : 'text-green-500'}`}>
                {Math.abs(stat.change)}%
              </span>
              <span className="text-sm text-gray-500 ml-1">{stat.period}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Emissions by Source</h3>
          <div className="space-y-4">
            {emissionSources.map((source, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white rounded-lg">
                    <source.icon className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{source.name}</p>
                    <p className="text-sm text-gray-500">{source.value} tCO2e</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{source.percentage}%</p>
                  <p className={`text-sm ${source.change > 0 ? 'text-red-500' : 'text-green-500'}`}>
                    {source.change > 0 ? '+' : ''}{source.change}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Facility Overview</h3>
          <div className="space-y-4">
            {facilities.map((facility, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white rounded-lg">
                    <Building2 className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{facility.name}</p>
                    <p className="text-sm text-gray-500">{facility.emissions} tCO2e</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {facility.alert && (
                    <AlertCircle className="h-5 w-5 text-amber-500" />
                  )}
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    facility.status === 'On Track' ? 'bg-green-100 text-green-700' :
                    facility.status === 'Warning' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {facility.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Emission Trends</h3>
            <select className="text-sm border-gray-300 rounded-lg">
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>Last 12 months</option>
            </select>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={emissionTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="month" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="emissions" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', strokeWidth: 2 }}
                  name="Emissions"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Carbon Intensity Map</h3>
            <select className="text-sm border-gray-300 rounded-lg">
              <option>All Facilities</option>
              <option>Manufacturing Only</option>
              <option>Distribution Only</option>
            </select>
          </div>
          <div className="h-64">
            <ComposableMap
              projectionConfig={{
                rotate: [-10, 0, 0],
                scale: 100
              }}
            >
              <ZoomableGroup center={[0, 0]} zoom={1}>
                <Geographies geography="/world-110m.json">
                  {({ geographies }) =>
                    geographies.map(geo => {
                      const intensity = carbonIntensityData.features.find(
                        f => f.id === geo.id
                      )?.intensity || 0;
                      
                      return (
                        <Geography
                          key={geo.rsmKey}
                          geography={geo}
                          fill={colorScale(intensity)}
                          stroke="#FFF"
                          strokeWidth={0.5}
                          style={{
                            default: {
                              outline: 'none'
                            },
                            hover: {
                              outline: 'none',
                              fill: '#F3F4F6'
                            }
                          }}
                        />
                      );
                    })
                  }
                </Geographies>
              </ZoomableGroup>
            </ComposableMap>
          </div>
          <div className="flex items-center justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-[#10B981]" />
              <span className="text-xs text-gray-600">&lt;200</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-[#FCD34D]" />
              <span className="text-xs text-gray-600">200-400</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-[#F59E0B]" />
              <span className="text-xs text-gray-600">400-600</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-[#EF4444]" />
              <span className="text-xs text-gray-600">&gt;600</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;