import React, { useState } from 'react';
import { Target, ArrowUpRight, Plus, Filter, Download, Calendar, Check, AlertTriangle, XCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Targets = () => {
  const [timeRange, setTimeRange] = useState('year');
  const [targetType, setTargetType] = useState('all');

  const targets = [
    {
      name: '2025 Carbon Neutral',
      type: 'Emissions',
      baseline: 2020,
      target: 0,
      current: 1234,
      progress: 68,
      status: 'on-track',
      deadline: '2025-12-31'
    },
    {
      name: 'Renewable Energy',
      type: 'Energy',
      baseline: 2020,
      target: 100,
      current: 45,
      progress: 45,
      status: 'at-risk',
      deadline: '2026-12-31'
    },
    {
      name: 'Supply Chain Emissions',
      type: 'Scope 3',
      baseline: 2021,
      target: 50,
      current: 78,
      progress: 32,
      status: 'behind',
      deadline: '2024-12-31'
    },
    {
      name: 'Energy Efficiency',
      type: 'Energy',
      baseline: 2020,
      target: 30,
      current: 22,
      progress: 73,
      status: 'on-track',
      deadline: '2025-06-30'
    }
  ];

  const progressData = [
    { month: 'Jan', actual: 1500, target: 1450 },
    { month: 'Feb', actual: 1450, target: 1400 },
    { month: 'Mar', actual: 1400, target: 1350 },
    { month: 'Apr', actual: 1320, target: 1300 },
    { month: 'May', actual: 1280, target: 1250 },
    { month: 'Jun', actual: 1234, target: 1200 }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value} tCO2e
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Targets</h1>
          <p className="text-gray-500">Track and manage your sustainability targets</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-4 w-4" />
            Filter
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Plus className="h-4 w-4" />
            Add Target
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Progress Tracking</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="actual" stroke="#10B981" name="Actual" strokeWidth={2} />
                <Line type="monotone" dataKey="target" stroke="#6B7280" name="Target" strokeWidth={2} strokeDasharray="5 5" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Target Overview</h3>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Targets</p>
                <p className="text-2xl font-bold text-gray-900">{targets.length}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">On Track</p>
                <p className="text-2xl font-bold text-green-600">
                  {targets.filter(t => t.status === 'on-track').length}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">At Risk</p>
                <p className="text-2xl font-bold text-amber-500">
                  {targets.filter(t => t.status === 'at-risk').length}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Behind</p>
                <p className="text-2xl font-bold text-red-500">
                  {targets.filter(t => t.status === 'behind').length}
                </p>
              </div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-medium text-gray-900 mb-2">Next Milestone</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">Supply Chain Emissions Target</span>
                </div>
                <span className="text-sm font-medium text-amber-600">Due in 3 months</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Target Details</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {targets.map((target, index) => (
            <div key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <Target className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">{target.name}</h4>
                    <p className="text-sm text-gray-500">
                      {target.type} • Baseline Year: {target.baseline}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div>
                    <p className="text-sm text-gray-500">Current Value</p>
                    <p className="text-lg font-medium text-gray-900">{target.current}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Target</p>
                    <p className="text-lg font-medium text-gray-900">{target.target}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Progress</p>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-gray-200 rounded-full">
                        <div
                          className={`h-2 rounded-full ${
                            target.status === 'on-track' ? 'bg-green-500' :
                            target.status === 'at-risk' ? 'bg-amber-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${target.progress}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium text-gray-600">{target.progress}%</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <div className="flex items-center gap-1">
                      {target.status === 'on-track' ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : target.status === 'at-risk' ? (
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className={`text-sm font-medium ${
                        target.status === 'on-track' ? 'text-green-500' :
                        target.status === 'at-risk' ? 'text-amber-500' : 'text-red-500'
                      }`}>
                        {target.status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                      </span>
                    </div>
                  </div>
                  <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-50 rounded-lg hover:bg-gray-100">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Targets;