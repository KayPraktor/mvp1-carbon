import React, { useState } from 'react';
import { AlertCircle, Bell, Calendar, Clock, Filter, Plus, Settings, Shield, Sliders, ThumbsUp, AlertTriangle, XCircle, CheckCircle2 } from 'lucide-react';

const Alerts = ({ darkMode }) => {
  const [activeTab, setActiveTab] = useState('active');

  const alertConfigurations = [
    {
      id: 'emissions-threshold',
      name: 'Emissions Threshold Alert',
      description: 'Alert when facility emissions exceed defined threshold',
      type: 'Threshold',
      priority: 'High',
      recipients: ['operations@example.com', 'facility-managers@example.com'],
      conditions: [
        { metric: 'Daily Emissions', operator: '>', value: '100 tCO2e' },
        { metric: 'Weekly Average', operator: '>', value: '90 tCO2e' }
      ],
      status: 'Active'
    },
    {
      id: 'data-quality',
      name: 'Data Quality Alert',
      description: 'Monitor data quality and completeness',
      type: 'System',
      priority: 'Medium',
      recipients: ['data-team@example.com'],
      conditions: [
        { metric: 'Data Completeness', operator: '<', value: '95%' },
        { metric: 'Data Latency', operator: '>', value: '24 hours' }
      ],
      status: 'Active'
    },
    {
      id: 'compliance-deadline',
      name: 'Compliance Deadline Alert',
      description: 'Reminder for upcoming compliance deadlines',
      type: 'Schedule',
      priority: 'High',
      recipients: ['compliance@example.com', 'legal@example.com'],
      conditions: [
        { metric: 'Days to Deadline', operator: '<=', value: '30 days' }
      ],
      status: 'Active'
    }
  ];

  const activeAlerts = [
    {
      id: 1,
      title: 'High Emissions Detected',
      facility: 'Main Factory - London',
      type: 'Threshold',
      priority: 'High',
      timestamp: '2024-03-18 09:15',
      description: 'Daily emissions exceeded threshold by 15%',
      status: 'New'
    },
    {
      id: 2,
      title: 'Data Quality Issue',
      facility: 'Distribution Center - Manchester',
      type: 'System',
      priority: 'Medium',
      timestamp: '2024-03-18 08:30',
      description: 'Missing data points in last 4 hours',
      status: 'Acknowledged'
    },
    {
      id: 3,
      title: 'Compliance Deadline Approaching',
      facility: 'All Facilities',
      type: 'Schedule',
      priority: 'High',
      timestamp: '2024-03-17 14:20',
      description: 'Annual compliance report due in 15 days',
      status: 'In Progress'
    }
  ];

  const alertHistory = [
    {
      id: 4,
      title: 'System Maintenance',
      facility: 'All Facilities',
      type: 'System',
      priority: 'Low',
      timestamp: '2024-03-15 02:00',
      description: 'Scheduled system maintenance completed',
      status: 'Resolved',
      resolution: 'Maintenance completed successfully'
    },
    {
      id: 5,
      title: 'Data Sync Error',
      facility: 'Warehouse - Leeds',
      type: 'System',
      priority: 'Medium',
      timestamp: '2024-03-14 15:45',
      description: 'Failed to sync facility data',
      status: 'Resolved',
      resolution: 'Network connectivity restored'
    }
  ];

  const getPriorityColor = (priority) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'text-red-500 bg-red-50 dark:bg-red-900/20';
      case 'medium':
        return 'text-amber-500 bg-amber-50 dark:bg-amber-900/20';
      case 'low':
        return 'text-blue-500 bg-blue-50 dark:bg-blue-900/20';
      default:
        return 'text-gray-500 bg-gray-50 dark:bg-gray-700';
    }
  };

  const getStatusIcon = (status) => {
    switch (status.toLowerCase()) {
      case 'new':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'acknowledged':
        return <ThumbsUp className="h-4 w-4 text-blue-500" />;
      case 'in progress':
        return <Clock className="h-4 w-4 text-amber-500" />;
      case 'resolved':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Alerts</h1>
          <p className="text-gray-500 dark:text-gray-400">Monitor and manage system alerts</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <Settings className="h-4 w-4" />
            Settings
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
            <Plus className="h-4 w-4" />
            New Alert
          </button>
        </div>
      </div>

      <div className="mb-6">
        <nav className="flex gap-4">
          {['active', 'configurations', 'history'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium rounded-lg ${
                activeTab === tab
                  ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      {activeTab === 'active' && (
        <div className="space-y-6">
          {activeAlerts.map((alert) => (
            <div
              key={alert.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${getPriorityColor(alert.priority)}`}>
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{alert.title}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{alert.facility}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${getPriorityColor(alert.priority)}`}>
                    {alert.priority}
                  </span>
                  <div className="flex items-center gap-1">
                    {getStatusIcon(alert.status)}
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-300">{alert.status}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-4">{alert.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  <span>{alert.timestamp}</span>
                </div>
                <div className="flex gap-2">
                  <button className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600">
                    Acknowledge
                  </button>
                  <button className="px-4 py-2 text-sm font-medium text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-900/20 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30">
                    Resolve
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'configurations' && (
        <div className="space-y-6">
          {alertConfigurations.map((config) => (
            <div
              key={config.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <Sliders className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{config.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{config.description}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 text-xs font-medium rounded-full ${getPriorityColor(config.priority)}`}>
                  {config.priority}
                </span>
              </div>
              <div className="space-y-4 mb-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Conditions</h4>
                  <div className="space-y-2">
                    {config.conditions.map((condition, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300"
                      >
                        <Shield className="h-4 w-4 text-gray-400" />
                        <span>{condition.metric}</span>
                        <span>{condition.operator}</span>
                        <span>{condition.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Recipients</h4>
                  <div className="flex flex-wrap gap-2">
                    {config.recipients.map((recipient, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-full"
                      >
                        {recipient}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600">
                  Edit
                </button>
                <button className="px-4 py-2 text-sm font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'history' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Alert History</h3>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {alertHistory.map((alert) => (
              <div key={alert.id} className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${getPriorityColor(alert.priority)}`}>
                      <AlertTriangle className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white">{alert.title}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{alert.facility}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`px-3 py-1 text-xs font-medium rounded-full ${getPriorityColor(alert.priority)}`}>
                      {alert.priority}
                    </span>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(alert.status)}
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-300">{alert.status}</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <p className="text-gray-600 dark:text-gray-300">{alert.description}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Resolution: {alert.resolution}</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  <span>{alert.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Alerts;