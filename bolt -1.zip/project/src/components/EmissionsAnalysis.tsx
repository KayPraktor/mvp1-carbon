import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
  Area
} from 'recharts';
import { Filter, Download, Calendar, ArrowUpRight, ArrowDownRight, Info, FileText } from 'lucide-react';

const EmissionsAnalysis = ({ darkMode }) => {
  const [timeRange, setTimeRange] = useState('year');
  const [analysisType, setAnalysisType] = useState('trends');
  const [exportLoading, setExportLoading] = useState(false);

  // Sample data for emissions analysis
  const emissionTrends = [
    { month: 'Jan', scope1: 320, scope2: 240, scope3: 580, total: 1140 },
    { month: 'Feb', scope1: 310, scope2: 230, scope3: 570, total: 1110 },
    { month: 'Mar', scope1: 315, scope2: 225, scope3: 560, total: 1100 },
    { month: 'Apr', scope1: 300, scope2: 220, scope3: 540, total: 1060 },
    { month: 'May', scope1: 290, scope2: 215, scope3: 520, total: 1025 },
    { month: 'Jun', scope1: 280, scope2: 210, scope3: 510, total: 1000 },
    { month: 'Jul', scope1: 275, scope2: 205, scope3: 500, total: 980 },
    { month: 'Aug', scope1: 270, scope2: 200, scope3: 490, total: 960 },
    { month: 'Sep', scope1: 265, scope2: 195, scope3: 480, total: 940 },
    { month: 'Oct', scope1: 260, scope2: 190, scope3: 470, total: 920 },
    { month: 'Nov', scope1: 255, scope2: 185, scope3: 460, total: 900 },
    { month: 'Dec', scope1: 250, scope2: 180, scope3: 450, total: 880 }
  ];

  const emissionsBySource = [
    { name: 'Electricity', value: 420, percentage: 34 },
    { name: 'Natural Gas', value: 280, percentage: 23 },
    { name: 'Fleet Vehicles', value: 210, percentage: 17 },
    { name: 'Purchased Goods', value: 180, percentage: 15 },
    { name: 'Business Travel', value: 130, percentage: 11 }
  ];

  const intensityData = [
    { year: 2018, intensity: 0.58, revenue: 100 },
    { year: 2019, intensity: 0.54, revenue: 120 },
    { year: 2020, intensity: 0.51, revenue: 110 },
    { year: 2021, intensity: 0.48, revenue: 140 },
    { year: 2022, intensity: 0.45, revenue: 160 },
    { year: 2023, intensity: 0.42, revenue: 180 },
    { year: 2024, intensity: 0.38, revenue: 200 }
  ];

  const forecastData = [
    { year: 2020, actual: 1200, forecast: null, target: 1200 },
    { year: 2021, actual: 1150, forecast: null, target: 1100 },
    { year: 2022, actual: 1080, forecast: null, target: 1000 },
    { year: 2023, actual: 1000, forecast: null, target: 900 },
    { year: 2024, actual: 920, forecast: null, target: 800 },
    { year: 2025, actual: null, forecast: 850, target: 700 },
    { year: 2026, actual: null, forecast: 780, target: 600 },
    { year: 2027, actual: null, forecast: 720, target: 500 },
    { year: 2028, actual: null, forecast: 650, target: 400 },
    { year: 2029, actual: null, forecast: 580, target: 300 },
    { year: 2030, actual: null, forecast: 500, target: 200 }
  ];

  const benchmarkData = [
    { name: 'Your Company', value: 0.42 },
    { name: 'Industry Average', value: 0.58 },
    { name: 'Industry Leader', value: 0.31 },
    { name: 'Regulatory Target', value: 0.35 }
  ];

  const COLORS = ['#10B981', '#3B82F6', '#6366F1', '#8B5CF6', '#EC4899'];
  const SCOPE_COLORS = {
    scope1: '#10B981',
    scope2: '#3B82F6',
    scope3: '#6366F1',
    total: '#8B5CF6'
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className={`p-4 rounded-lg shadow-sm ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border`}>
          <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value} {entry.name === 'intensity' ? 'tCO₂e/$M' : entry.name.includes('scope') ? 'tCO₂e' : ''}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const handleExportData = () => {
    setExportLoading(true);
    
    try {
      // Prepare the data for export
      const exportData = {
        emissionTrends,
        emissionsBySource,
        intensityData,
        forecastData,
        benchmarkData,
        exportDate: new Date().toISOString(),
        timeRange,
        analysisType
      };
      
      // Convert to JSON string
      const jsonString = JSON.stringify(exportData, null, 2);
      
      // Create a blob and download link
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Create a temporary link element and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `emissions-analysis-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      console.log('Export completed successfully');
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setExportLoading(false);
    }
  };

  const generatePDF = () => {
    // PDF generation logic would go here
    console.log('PDF generation triggered');
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emissions Analysis</h1>
          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Advanced analysis and forecasting of carbon emissions</p>
        </div>
        <div className="flex gap-4">
          <div className={`flex items-center gap-2 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-lg border px-4 py-2`}>
            <Calendar className={`h-5 w-5 ${darkMode ? 'text-gray-400' : 'text-gray-400'}`} />
            <select 
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className={`text-sm ${darkMode ? 'text-gray-300 bg-gray-800' : 'text-gray-600 bg-white'} border-none focus:ring-0`}
            >
              <option value="quarter">Last Quarter</option>
              <option value="year">Last Year</option>
              <option value="5year">Last 5 Years</option>
            </select>
          </div>
          <button 
            onClick={handleExportData}
            disabled={exportLoading}
            className={`flex items-center gap-2 px-4 py-2 ${darkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'} border rounded-lg text-sm`}
          >
            <Download className="h-5 w-5" />
            {exportLoading ? 'Exporting...' : 'Export Data'}
          </button>
          <button 
            onClick={generatePDF}
            className={`flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm hover:bg-green-700`}
          >
            <FileText className="h-5 w-5" />
            Generate Report
          </button>
        </div>
      </div>

      <div className="mb-6">
        <nav className="flex gap-4">
          {['trends', 'sources', 'intensity', 'forecast', 'benchmark'].map((type) => (
            <button
              key={type}
              onClick={() => setAnalysisType(type)}
              className={`px-4 py-2 text-sm font-medium rounded-lg ${
                analysisType === type
                  ? `${darkMode ? 'bg-green-900/20 text-green-400' : 'bg-green-50 text-green-700'}`
                  : `${darkMode ? 'text-gray-400 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-50'}`
              }`}
            >
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      {analysisType === 'trends' && (
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-xl shadow-sm p-6`}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emissions Trends by Scope</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Monthly breakdown of emissions by scope</p>
            </div>
          </div>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={emissionTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="month" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="scope1" stackId="a" fill={SCOPE_COLORS.scope1} name="Scope 1" />
                <Bar dataKey="scope2" stackId="a" fill={SCOPE_COLORS.scope2} name="Scope 2" />
                <Bar dataKey="scope3" stackId="a" fill={SCOPE_COLORS.scope3} name="Scope 3" />
                <Line type="monotone" dataKey="total" stroke={SCOPE_COLORS.total} name="Total" strokeWidth={2} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-6">
            {['scope1', 'scope2', 'scope3', 'total'].map((scope, index) => {
              const currentValue = emissionTrends[emissionTrends.length - 1][scope];
              const previousValue = emissionTrends[emissionTrends.length - 2][scope];
              const change = ((currentValue - previousValue) / previousValue) * 100;
              
              return (
                <div key={index} className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'} p-4 rounded-lg`}>
                  <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    {scope === 'scope1' ? 'Scope 1' : 
                     scope === 'scope2' ? 'Scope 2' : 
                     scope === 'scope3' ? 'Scope 3' : 'Total'}
                  </p>
                  <div className="flex items-baseline">
                    <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      {currentValue}
                    </h3>
                    <span className={`ml-1 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>tCO₂e</span>
                  </div>
                  <div className="flex items-center mt-1">
                    {change < 0 ? (
                      <ArrowDownRight className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <ArrowUpRight className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span className={`text-sm ${change < 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {Math.abs(change).toFixed(1)}%
                    </span>
                    <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'} ml-1`}>vs previous</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {analysisType === 'sources' && (
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-xl shadow-sm p-6`}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emissions by Source</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Breakdown of emissions by source category</p>
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={emissionsBySource}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  >
                    {emissionsBySource.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-4">
              {emissionsBySource.map((source, index) => (
                <div key={index} className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'} p-4 rounded-lg`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                      <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{source.name}</p>
                    </div>
                    <div>
                      <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{source.value} tCO₂e</p>
                      <p className={`text-sm text-right ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{source.percentage}% of total</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {analysisType === 'intensity' && (
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-xl shadow-sm p-6`}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Carbon Intensity Analysis</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Emissions per million dollars of revenue</p>
            </div>
          </div>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={intensityData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="year" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <YAxis yAxisId="left" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <YAxis yAxisId="right" orientation="right" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar yAxisId="right" dataKey="revenue" fill="#3B82F6" name="Revenue ($M)" />
                <Line yAxisId="left" type="monotone" dataKey="intensity" stroke="#10B981" strokeWidth={2} name="Carbon Intensity" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 flex items-start gap-2">
            <Info className={`h-4 w-4 ${darkMode ? 'text-gray-400' : 'text-gray-400'} mt-1`} />
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              Carbon intensity measures the amount of carbon emissions per unit of economic output.
              A decreasing trend indicates improved efficiency and decoupling of emissions from growth.
            </p>
          </div>
        </div>
      )}

      {analysisType === 'forecast' && (
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-xl shadow-sm p-6`}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emissions Forecast</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Projected emissions through 2030</p>
            </div>
          </div>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="year" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="actual" fill="#3B82F680" stroke="#3B82F6" name="Actual Emissions" />
                <Area type="monotone" dataKey="forecast" fill="#6366F180" stroke="#6366F1" name="Forecast Emissions" />
                <Line type="monotone" dataKey="target" stroke="#10B981" strokeWidth={2} strokeDasharray="5 5" name="Target Pathway" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'} p-4 rounded-lg`}>
              <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>Current Emissions (2024)</p>
              <div className="flex items-baseline">
                <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  920
                </h3>
                <span className={`ml-1 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>tCO₂e</span>
              </div>
            </div>
            <div className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'} p-4 rounded-lg`}>
              <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>Projected 2030 Emissions</p>
              <div className="flex items-baseline">
                <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  500
                </h3>
                <span className={`ml-1 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>tCO₂e</span>
              </div>
            </div>
            <div className={`${darkMode ? 'bg-gray-700' : 'bg-gray-50'} p-4 rounded-lg`}>
              <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>Reduction by 2030</p>
              <div className="flex items-baseline">
                <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  46
                </h3>
                <span className={`ml-1 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {analysisType === 'benchmark' && (
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border rounded-xl shadow-sm p-6`}>
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Benchmark Analysis</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Carbon intensity comparison (tCO₂e/$M)</p>
            </div>
          </div>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={benchmarkData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis type="number" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <YAxis dataKey="name" type="category" stroke={darkMode ? '#9CA3AF' : '#6B7280'} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Carbon Intensity">
                  {benchmarkData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.name === 'Your Company' ? '#10B981' : 
                            entry.name === 'Industry Leader' ? '#3B82F6' : 
                            entry.name === 'Regulatory Target' ? '#6366F1' : '#8B5CF6'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 flex items-start gap-2">
            <Info className={`h-4 w-4 ${darkMode ? 'text-gray-400' : 'text-gray-400'} mt-1`} />
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              Your company's carbon intensity is 27.6% below the industry average, but still 35.5% higher than the industry leader.
              Current performance is 20% above the regulatory target for 2025.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmissionsAnalysis;