import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ComposedChart,
  Area,
} from 'recharts';
import {
  ComposableMap,
  Geographies,
  Geography,
  ZoomableGroup,
} from 'react-simple-maps';
import { scaleLinear } from 'd3-scale';
import { Info, Download, Filter } from 'lucide-react';

// Complete emissions data from 1990-2023
const emissionsData = [
  {
    year: 1990,
    total: 22.0,
    china: 2.4,
    usa: 5.1,
    eu: 4.4,
    india: 0.6,
    russia: 3.2,
    japan: 1.2,
    germany: 1.0,
    iran: 0.2,
    canada: 0.5,
    saudi: 0.2,
    energy: 8.5,
    transport: 4.2,
    industry: 5.8,
    agriculture: 3.5,
  },
  {
    year: 1995,
    total: 23.1,
    china: 3.5,
    usa: 5.3,
    eu: 4.1,
    india: 0.8,
    russia: 2.5,
    japan: 1.3,
    germany: 0.9,
    iran: 0.3,
    canada: 0.5,
    saudi: 0.3,
    energy: 9.0,
    transport: 4.5,
    industry: 5.9,
    agriculture: 3.7,
  },
  {
    year: 2000,
    total: 25.4,
    china: 4.6,
    usa: 5.8,
    eu: 4.0,
    india: 1.2,
    russia: 2.2,
    japan: 1.3,
    germany: 0.9,
    iran: 0.4,
    canada: 0.6,
    saudi: 0.3,
    energy: 10.2,
    transport: 5.1,
    industry: 6.3,
    agriculture: 3.8,
  },
  {
    year: 2005,
    total: 28.5,
    china: 6.8,
    usa: 5.9,
    eu: 4.1,
    india: 1.5,
    russia: 2.2,
    japan: 1.3,
    germany: 0.8,
    iran: 0.5,
    canada: 0.6,
    saudi: 0.4,
    energy: 11.5,
    transport: 5.8,
    industry: 7.2,
    agriculture: 4.0,
  },
  {
    year: 2010,
    total: 31.2,
    china: 8.9,
    usa: 5.5,
    eu: 3.8,
    india: 1.8,
    russia: 2.1,
    japan: 1.2,
    germany: 0.8,
    iran: 0.6,
    canada: 0.5,
    saudi: 0.5,
    energy: 12.3,
    transport: 6.4,
    industry: 8.2,
    agriculture: 4.3,
  },
  {
    year: 2015,
    total: 33.1,
    china: 10.5,
    usa: 5.1,
    eu: 3.4,
    india: 2.1,
    russia: 1.8,
    japan: 1.1,
    germany: 0.8,
    iran: 0.6,
    canada: 0.5,
    saudi: 0.6,
    energy: 13.0,
    transport: 6.8,
    industry: 8.7,
    agriculture: 4.6,
  },
  {
    year: 2020,
    total: 34.2,
    china: 11.5,
    usa: 4.7,
    eu: 2.9,
    india: 2.4,
    russia: 1.6,
    japan: 1.0,
    germany: 0.7,
    iran: 0.7,
    canada: 0.5,
    saudi: 0.6,
    energy: 13.5,
    transport: 7.2,
    industry: 8.7,
    agriculture: 4.8,
  },
  {
    year: 2023,
    total: 36.8,
    china: 12.1,
    usa: 4.5,
    eu: 2.7,
    india: 2.7,
    russia: 1.7,
    japan: 0.9,
    germany: 0.6,
    iran: 0.8,
    canada: 0.5,
    saudi: 0.7,
    energy: 14.2,
    transport: 7.8,
    industry: 9.6,
    agriculture: 5.2,
  },
];

// Complete carbon intensity data for major economies
const carbonIntensityData = {
  type: "FeatureCollection",
  features: [
    { id: "CHN", intensity: 443, name: "China" },
    { id: "USA", intensity: 223, name: "United States" },
    { id: "IND", intensity: 412, name: "India" },
    { id: "RUS", intensity: 496, name: "Russia" },
    { id: "JPN", intensity: 185, name: "Japan" },
    { id: "DEU", intensity: 156, name: "Germany" },
    { id: "CAN", intensity: 298, name: "Canada" },
    { id: "GBR", intensity: 142, name: "United Kingdom" },
    { id: "KOR", intensity: 328, name: "South Korea" },
    { id: "FRA", intensity: 105, name: "France" },
    { id: "IRN", intensity: 587, name: "Iran" },
    { id: "SAU", intensity: 452, name: "Saudi Arabia" },
    { id: "IDN", intensity: 378, name: "Indonesia" },
    { id: "BRA", intensity: 156, name: "Brazil" },
    { id: "MEX", intensity: 234, name: "Mexico" },
    { id: "AUS", intensity: 312, name: "Australia" },
    { id: "ZAF", intensity: 598, name: "South Africa" },
    { id: "TUR", intensity: 267, name: "Turkey" },
    { id: "ITA", intensity: 147, name: "Italy" },
    { id: "POL", intensity: 289, name: "Poland" }
  ]
};

const colorScale = scaleLinear()
  .domain([0, 200, 400, 600])
  .range(["#10B981", "#FCD34D", "#F59E0B", "#EF4444"]);

const EmissionsVisualization = () => {
  const [mapZoom, setMapZoom] = useState(1);
  const [selectedView, setSelectedView] = useState('total');
  const [hoveredCountry, setHoveredCountry] = useState(null);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900 mb-2">{label}</p>
          {payload.map((entry, index) => (
            <p
              key={index}
              className="text-sm"
              style={{ color: entry.color }}
            >
              {entry.name}: {entry.value.toFixed(1)} Gt CO₂
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Global Emissions Analysis</h1>
          <p className="text-gray-500">Comprehensive visualization of global greenhouse gas emissions</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-4 w-4" />
            Filter Data
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4" />
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {/* Annual Emissions Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Annual Greenhouse Gas Emissions (1990-2023)</h2>
              <p className="text-sm text-gray-500">Global emissions trends by country and sector</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedView('total')}
                className={`px-3 py-1.5 text-sm font-medium rounded-lg ${
                  selectedView === 'total'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                Total Emissions
              </button>
              <button
                onClick={() => setSelectedView('countries')}
                className={`px-3 py-1.5 text-sm font-medium rounded-lg ${
                  selectedView === 'countries'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                By Country
              </button>
              <button
                onClick={() => setSelectedView('sectors')}
                className={`px-3 py-1.5 text-sm font-medium rounded-lg ${
                  selectedView === 'sectors'
                    ? 'bg-green-100 text-green-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                By Sector
              </button>
            </div>
          </div>
          
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              {selectedView === 'total' ? (
                <ComposedChart data={emissionsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="year" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" unit=" Gt" />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="total"
                    fill="#10B98133"
                    stroke="#10B981"
                    name="Total Emissions"
                  />
                </ComposedChart>
              ) : selectedView === 'countries' ? (
                <LineChart data={emissionsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="year" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" unit=" Gt" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="china" stroke="#EF4444" name="China" />
                  <Line type="monotone" dataKey="usa" stroke="#3B82F6" name="USA" />
                  <Line type="monotone" dataKey="eu" stroke="#10B981" name="EU" />
                  <Line type="monotone" dataKey="india" stroke="#F59E0B" name="India" />
                  <Line type="monotone" dataKey="russia" stroke="#8B5CF6" name="Russia" />
                </LineChart>
              ) : (
                <LineChart data={emissionsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="year" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" unit=" Gt" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="energy" stroke="#EF4444" name="Energy" />
                  <Line type="monotone" dataKey="transport" stroke="#3B82F6" name="Transport" />
                  <Line type="monotone" dataKey="industry" stroke="#10B981" name="Industry" />
                  <Line type="monotone" dataKey="agriculture" stroke="#F59E0B" name="Agriculture" />
                </LineChart>
              )}
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 flex items-start gap-2">
            <Info className="h-4 w-4 text-gray-400 mt-1" />
            <p className="text-sm text-gray-500">
              Data source: International Energy Agency (IEA) and World Bank, 2023.
              Values are in gigatonnes of CO₂ equivalent (Gt CO₂e).
            </p>
          </div>
        </div>

        {/* Carbon Intensity Map */}
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Global Carbon Intensity (2023)</h2>
            <p className="text-sm text-gray-500">CO₂ emissions per GDP (tons per $1M GDP)</p>
          </div>
          
          <div className="h-[600px] relative">
            <ComposableMap
              projectionConfig={{
                rotate: [-10, 0, 0],
                scale: 147
              }}
            >
              <ZoomableGroup zoom={mapZoom} center={[0, 0]}>
                <Geographies geography="/world-110m.json">
                  {({ geographies }) =>
                    geographies.map(geo => {
                      const intensity = carbonIntensityData.features.find(
                        f => f.id === geo.id
                      )?.intensity || 0;
                      
                      return (
                        <Geography
                          key={geo.rsmKey}
                          geography={geo}
                          fill={colorScale(intensity)}
                          stroke="#FFF"
                          strokeWidth={0.5}
                          onMouseEnter={() => {
                            const country = carbonIntensityData.features.find(f => f.id === geo.id);
                            setHoveredCountry(country);
                          }}
                          onMouseLeave={() => {
                            setHoveredCountry(null);
                          }}
                          style={{
                            default: {
                              outline: 'none'
                            },
                            hover: {
                              outline: 'none',
                              fill: '#F3F4F6'
                            }
                          }}
                        />
                      );
                    })
                  }
                </Geographies>
              </ZoomableGroup>
            </ComposableMap>
            
            {hoveredCountry && (
              <div className="absolute top-4 right-4 bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                <h3 className="font-medium text-gray-900">{hoveredCountry.name}</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Carbon Intensity: {hoveredCountry.intensity} tons/$1M GDP
                </p>
              </div>
            )}
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-8">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#10B981]" />
                  <span className="text-sm text-gray-600">&lt;200</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#FCD34D]" />
                  <span className="text-sm text-gray-600">200-400</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#F59E0B]" />
                  <span className="text-sm text-gray-600">400-600</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-[#EF4444]" />
                  <span className="text-sm text-gray-600">&gt;600</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setMapZoom(prev => Math.max(1, prev - 0.5))}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded"
                >
                  -
                </button>
                <button
                  onClick={() => setMapZoom(prev => Math.min(4, prev + 0.5))}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded"
                >
                  +
                </button>
              </div>
            </div>
            
            <div className="flex items-start gap-2">
              <Info className="h-4 w-4 text-gray-400 mt-1" />
              <p className="text-sm text-gray-500">
                Data source: World Bank Development Indicators, 2023.
                Carbon intensity is measured in tons of CO₂ per million dollars of GDP (PPP).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmissionsVisualization;