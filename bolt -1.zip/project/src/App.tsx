import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Analytics from './components/Analytics';
import EmissionSources from './components/EmissionSources';
import Facilities from './components/Facilities';
import Targets from './components/Targets';
import EmissionsVisualization from './components/EmissionsVisualization';
import Reports from './components/Reports';
import Alerts from './components/Alerts';
import EmissionsAnalysis from './components/EmissionsAnalysis';
import { Moon, Sun } from 'lucide-react';

function App() {
  const [currentPage, setCurrentPage] = useState('analysis');
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`flex h-screen ${darkMode ? 'dark' : ''}`}>
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} darkMode={darkMode} />
      <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        <div className="h-16 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-800 px-8 flex items-center justify-end">
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            {darkMode ? (
              <Sun className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            ) : (
              <Moon className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            )}
          </button>
        </div>
        <main className="flex-1 overflow-y-auto">
          {currentPage === 'dashboard' && <Dashboard darkMode={darkMode} />}
          {currentPage === 'analytics' && <Analytics darkMode={darkMode} />}
          {currentPage === 'emissions' && <EmissionSources darkMode={darkMode} />}
          {currentPage === 'facilities' && <Facilities darkMode={darkMode} />}
          {currentPage === 'targets' && <Targets darkMode={darkMode} />}
          {currentPage === 'visualization' && <EmissionsVisualization darkMode={darkMode} />}
          {currentPage === 'reports' && <Reports darkMode={darkMode} />}
          {currentPage === 'alerts' && <Alerts darkMode={darkMode} />}
          {currentPage === 'analysis' && <EmissionsAnalysis darkMode={darkMode} />}
        </main>
      </div>
    </div>
  );
}

export default App;